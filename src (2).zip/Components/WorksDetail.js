import React from 'react';
import { useNavigate } from 'react-router-dom';

const WorksDetail = () => {
  const navigate = useNavigate();
  const handleGoIntro = () => {
    navigate(-1);
  }
  return (
    <div>
      <button onClick={handleGoIntro}>뒤로가기</button>
      프로젝트 상세보기 페이지
    </div>
  )
}

export default WorksDetail
