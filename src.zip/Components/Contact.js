import React from 'react';
import { styled } from "styled-components";
import paperTextureImg from '../img/paper-texture.jpg';

const Container = styled.div`
  height: 100vh;
  background: url(${paperTextureImg}) no-repeat center;
  background-size: cover;
  
`;

const Contact = () => {
  return (
    <Container>
      Contact 구역입니다.
    </Container>
  )
}

export default Contact
