import React from 'react';
import { styled } from "styled-components";

const Container = styled.div`
  width: 100%;
  height: 4.375rem;
  position: fixed;

  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 3.75rem;

  box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.05);
  background-color: transparent;
`;
const Title = styled.h1`
  margin: 0;
  padding: 0;
  color: var(--darkblack);
  font-family: Noto Sans;
  font-size: 1.5rem;
  font-weight: 400;
`;
const Menu = styled.ul`
  display: flex;
  align-items: center;
  gap: 2.5rem;
`;
const List = styled.li`
  color: var(--darkblack);
  font-weight: 600; 
  &:hover {
    color: var(--green);
  }
`;

const NavBar = () => {
  return (
    <Container className='NavBar'>
      <Title>DAMI</Title>
      <Menu>
        <a href='#'><List>INTRO</List></a>
        <a href='#'><List>ABOUT</List></a>
        <a href='#'><List>WORKS</List></a>
        <a href='#'><List>CONTACT</List></a>
      </Menu>
    </Container>
  )
}

export default NavBar
