import React from 'react';
import { styled } from "styled-components";
import 'bootstrap/dist/css/bootstrap.min.css';
import Carousel from 'react-bootstrap/Carousel';


const Container = styled.div`
  height: 100vh;
`;
const Wrapper = styled.div`
  background-color: #fff;
  width: 75rem;
  height: 100%;
  margin: 0 auto;
  overflow: hidden;

  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
`;
const Contents = styled.div`
  border: 1px solid red;
`;
const Title = styled.h1`
  font-size: 2.25rem;
  color: var(--green);
  text-align: center;
`;

const Works = () => {
  return (
    <Container>
      <Wrapper>
        <Contents>
          <Title>WORKS</Title>
          {/* Slider */}
          <Carousel data-interval="false" data-bs-theme="dark">
            <Carousel.Item>
              <img
                src="http://placeholder.com/792x450"
                alt="First slide"
              />
              <Carousel.Caption>
                <h5>First slide label</h5>
                <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
              </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
              <img
                src="http://placeholder.com/792x450"
                alt="Second slide"
              />
              <Carousel.Caption>
                <h5>Second slide label</h5>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              </Carousel.Caption>
            </Carousel.Item>
            <Carousel.Item>
              <img
                className="d-block w-100"
                src="http://placeholder.com/792x450"
                alt="Third slide"
              />
              <Carousel.Caption>
                <h5>Third slide label</h5>
                <p>
                  Praesent commodo cursus magna, vel scelerisque nisl consectetur.
                </p>
              </Carousel.Caption>
            </Carousel.Item>
          </Carousel>
          {/* Slider */}
        </Contents>
      </Wrapper>
    </Container>
  )
}

export default Works
