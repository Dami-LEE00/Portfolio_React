import './App.css';
import { styled } from "styled-components";
import NavBar from './Components/NavBar';
import Intro from './Components/Intro';
import About from './Components/About';
import Works from './Components/Works';
import Contact from './Components/Contact';
import 'bootstrap/dist/css/bootstrap.min.css';

const Container = styled.div`
  width: 100%;
`;

function App() {
  return (
    <Container>
      <NavBar />
      <Intro />
      <About />
      <Works />
      <Contact />
    </Container>
  );
}

export default App;
