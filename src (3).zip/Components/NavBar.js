import React from 'react';
import { styled, css } from "styled-components";
import { Link } from 'react-scroll';
import { useState } from 'react';

const Container = styled.div`
  width: 100%;
  height: 4.375rem;
  position: fixed;

  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 3.75rem;

  // box-shadow: 3px 3px 10px rgba(0, 0, 0, 0.05);
  background-color: transparent;

  z-index: 9999;
`;
const Title = styled.h1`
  margin: 0;
  padding: 0;
  color: var(--darkblack);
  font-family: Noto Sans;
  font-size: 1.5rem;
  font-weight: 400;
`;
const Menu = styled.ul`
  display: flex;
  align-items: center;
  gap: 2.5rem;
`;
const List = styled.li`
  color: var(--darkblack);
  font-weight: 600; 
  position: relative;
  cursor: pointer;

  ::after {
    content: '';
    display: inline-block;
    position: absolute;
    left: 0;
    bottom: -0.125rem;

    width: 0;
    height: 0.125rem;
    
    transition: all 0.25s ease-in-out;
    transition-duration: 0.3s;
    opacity: 0;
    background-color: var(--green);

  }
  
  &:hover::after {
    width: 100%;
    opacity: 1;
  }

  &:hover {
    color: var(--green);
  }
  }
`;

const NavBar = () => {
  const data = ['HOME', 'ABOUT', 'WORKS', 'CONTACT'];
  const [menuActive, setMenuActive] = useState(false);

  const toggleActive = (prev) => {
    setMenuActive(e.target.value);
  }
  return (
    <Container className='NavBar'>
      <Title>DAMI</Title>
      <Menu>
        {data.map((item, idx) => {
          return (
            <List 
              onClick={toggleActive}
              key={idx}
              className={"btn" + (idx == menuActive ? "focus" : "")}
            >
              <Link to={item.toLowerCase()} smooth={true} duration={0}>{item}</Link>
            </List>
          )
        })}
        {/* <List>
          <Link to='home' smooth={true} duration={0}>HOME</Link>
        </List>
        <List>
          <Link to='about' smooth={true} duration={0}>ABOUT</Link>
        </List>
        <List>
          <Link to='works' smooth={true} duration={0}>WORKS</Link>
        </List>
        <List>
          <Link to='contact' smooth={true} duration={0}>CONTACT</Link>
        </List> */}
      </Menu>
    </Container>
  )
}

export default NavBar