import React from 'react';
import { styled } from "styled-components";
import NavBar from './NavBar';
import Home from './Home';
import About from './About';
import Works from './Works';
import Contact from './Contact';

const Container = styled.div`
  width: 100%;
  font-family: var(--primary-en);
  color: var(--darkblack);
  background-color: var(--f7);
  a {
    text-decoration: none;
  }
  ul {
    list-style: none;
    margin: 0!important;
    padding: 0!important;
  }
`;

const Intro = () => {
  return (
    <Container>
      <NavBar />
      <Home />
      <About />
      <Works />
      <Contact />
    </Container>
  )
}

export default Intro
